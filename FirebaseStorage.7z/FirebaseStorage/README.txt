This folder created for visualizing Firebase Storage what I use in my project. 
Assets [images, icons] what I use with Internet saved in this folder. 
For reduce file sizes I zip it.  